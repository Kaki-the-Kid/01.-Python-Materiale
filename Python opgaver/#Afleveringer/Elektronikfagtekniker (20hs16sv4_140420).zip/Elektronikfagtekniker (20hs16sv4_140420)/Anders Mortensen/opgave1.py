#Anders Mortenesen
#Dato: 15-04-2020

#Opgave 1

age = input("Hvad er din alder? ") #Brugeren skriver deres alder
name = input ("Hvad er dit navn? ") #Brugeren skriver deres navn

print("Hej " + name) 			#Der udskrives "Hej" og så brugerens navn
print("Du er " + age + " år gammel")	#Der udskrives "Du er", så brugerens alder og "år gammel"


def func(str): #udskriver strings
    print(str)
    return 0



