#Opgave 2

string = "Lorem ipsum dolor sit amet, consectetur adipiscing elit." #Laver string, som vi skal bearbejde
print(string[6:12]) #udskriver plads 6-12