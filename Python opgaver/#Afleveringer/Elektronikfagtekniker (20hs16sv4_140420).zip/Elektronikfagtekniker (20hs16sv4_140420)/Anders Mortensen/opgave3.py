# Anders Mortensen
# Dato: 15-04-2020

# Opgave 3

string = "Larsten er underviser på AARHUS TECH" #Laver den string, som vi skal bearbejde
print(string.replace("L","K")) #Erstatter L med K