# Anders Mortensen
# Dato: 15-04-2020

# Opgave 4

pris = input("Hvad er prisen uden moms?")
sum = int(pris)
moms = (sum/100)*20
print("Prisen er",sum + moms, "med moms")