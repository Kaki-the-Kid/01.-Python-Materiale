# Anders Chr. Rungborg
# 15-04-2020
# OPG Python

bruger = 4 
bruger = "brugeren AndersC" # her laver jeg variable til met brugeren
print("brugeren AndersC")

alder = 4 
alder = "alder"
print("alder 23")