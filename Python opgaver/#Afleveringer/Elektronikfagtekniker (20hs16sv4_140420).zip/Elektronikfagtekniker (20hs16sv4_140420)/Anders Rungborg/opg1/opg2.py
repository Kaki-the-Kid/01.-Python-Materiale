# Anders Chr. Rungborg
# 15-04-2020
# OPG Python


z = 4
z = "Lorem ipsum dolor sit amet, consectetur adipiscing elit"
print(z[6:12]) # den finder den den skal texte ved at fine logasjon af ore og så hvor lange der er  