# Anders Chr. Rungborg
# 15-04-2020
# OPG Python


c = 4
c = "Larsten er underviser på Aarhus tech"
print(c.replace("L","K"))                              # astader L med k 