# Anders Chr. Rungborg
# 15-04-2020
# OPG Python


pris = input("hvad er prisen")                   # har tager dit input  
print ("pris er" + (str(float(pris) * 1.25)))    # har buger den 1.25 men den kan godt bliver for fider når men granger med et array 



