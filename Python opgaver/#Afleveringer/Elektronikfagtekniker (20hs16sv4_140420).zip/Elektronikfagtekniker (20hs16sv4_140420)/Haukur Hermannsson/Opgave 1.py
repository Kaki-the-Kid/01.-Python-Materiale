# Haukur
# 15.04.2020
# Opgave 1

# Input en bruger og alder og skriv dem ud

age = input("Hvad er din alder? ")     # Indtast din alder
name = input("Hvad er dit navn? ")     # Indtast dit navn

print("Hej " + name)                   # Udskriver navnet
print("Du er " + age + " år gammel ")  # Udskriver alderen