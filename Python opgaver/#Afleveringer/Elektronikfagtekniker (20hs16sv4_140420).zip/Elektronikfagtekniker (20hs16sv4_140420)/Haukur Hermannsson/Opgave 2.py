# Haukur
# 15.04.2020
# Opgave 2

# Udskriv et bestemt ord fra en sætning.

a = "Lorem ipsum dolor sit amet, consectetur adipscing elit"  # Giver sætningen en variable.
print(a[6:12])                                                # Udskriver kun karaktererne med position 6 til 12 i linjen.