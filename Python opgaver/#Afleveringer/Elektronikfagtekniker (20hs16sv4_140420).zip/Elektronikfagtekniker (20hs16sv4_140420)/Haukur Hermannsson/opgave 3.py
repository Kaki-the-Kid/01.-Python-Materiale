# Haukur
# 15.04.2020
# Opgave 3

# "Find and replace" en bogstav i en sætning.

a = "Larsten er en underviser på AARHUS TECH"  # Angiver sætningen en variable
print(a.replace("L", "K"))                     # Udskriver og erstatter alle karaktere "L" med "K"