# Haukur
# 15.04.2020
# Opgave 4

# Regn en pris med moms

pris = input("Hvad er prisen? ")                        # Indtast pris uden moms
print("Prisen med moms er " + str(float(pris) * 1.25))  # Udskriv prisen regnet med moms