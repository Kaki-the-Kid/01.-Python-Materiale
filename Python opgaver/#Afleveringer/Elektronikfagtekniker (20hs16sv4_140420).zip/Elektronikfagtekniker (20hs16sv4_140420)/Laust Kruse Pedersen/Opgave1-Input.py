#Navn: Laust Kruse Pedersen
#Dato: 15/01/2020
#Opgave: 1

#To inputs der beder om Alder og Navn.
age = input("Hvad er din alder?")
name = input("Hvad er dit navn? ")

#Printer Input Navn og Alder.
print("Hej " + name)
print("Du er " + age + " gammel")

