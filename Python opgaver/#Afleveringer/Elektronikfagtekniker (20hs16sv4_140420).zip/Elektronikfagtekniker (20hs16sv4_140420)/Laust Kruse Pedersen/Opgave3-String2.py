#Navn: Laust Kruse Pedersen
#Dato: 15/01/2020
#Opgave: 3

#Variabel med en sætning.
txt = "Larsten er underviser på AARHUS TECH"
#Laver ændringer til Variabel.
x = txt.replace("L","K")
#Printer den ændre sætning.
print(x)