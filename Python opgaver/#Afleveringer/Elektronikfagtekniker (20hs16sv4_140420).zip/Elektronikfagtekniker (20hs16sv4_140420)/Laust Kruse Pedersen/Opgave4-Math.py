#Navn: Laust Kruse Pedersen
#Dato: 15/01/2020
#Opgave: 4

#Input netto pris i en float variabel.
netto = float(input("Hvad er Netto prisen? "))
#Variable for moms.
moms = 1.25
#Printer prisen med moms, ved at gange netto prisen med moms.
print("Prisen med Moms " + str(netto*moms))