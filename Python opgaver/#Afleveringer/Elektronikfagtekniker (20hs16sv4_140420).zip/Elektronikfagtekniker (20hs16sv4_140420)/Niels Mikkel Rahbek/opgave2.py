# Mikkel
# 15-04-2020
# Opgave 2

a = "Lorem ipsum dolor sit amet, consectetur adipiscing elit." # lægger stregen i a
print(a[6:12]) # printer plads 6 til 12 i strengen