# Mikkel
# 15-04-2020
# Opgave 3

a = "Larsten er underviser på AARHUS TECH" # lægger stregen i a
print(a.replace("L","K")) # printer strengen hvor den udskifter stort L med stort K