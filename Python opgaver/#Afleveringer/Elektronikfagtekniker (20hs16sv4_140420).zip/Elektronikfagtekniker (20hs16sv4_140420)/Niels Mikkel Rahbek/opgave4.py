# Mikkel
# 15-04-2020
# Opgave 4

netto = input("Hvad er netto prisen i kr? ") # laver netto til input/streng man skal taste


print("Prisen med moms er: " + (str(float(netto) * 1.25)) + " kr") # printer teksten, kalder strengen(som float så den også kan tage decimaler), ganger strengen med momsen

               