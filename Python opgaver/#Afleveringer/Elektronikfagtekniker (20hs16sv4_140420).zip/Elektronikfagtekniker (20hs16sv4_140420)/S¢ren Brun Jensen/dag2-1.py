#/bin/python3.7								#specificerer interpreter



print("Skriv dit navn: ")					#Udskriver "<TEXT>" til terminalen

navn = input()								#Gemmer inputtet fra terminalen i variablen navn, som en string

print("Indtast din alder: ")				#Udskring "<TEXT>" til terminalen

alder = input()								#Gemmer inputtet fra terminalen i variablen navn, som en string

print(navn + " er " + alder + " gammel.")	#Udskriver en string sammensat af variabler og tekst
