#Navn Thomas Suder
#Dato 15/04/2020
#Opgave 2

Lorem ="Lorem ipsum dolor sit amet, consectetur adipiscing elit. "
#printer fra position 6 til 11. Hvor ipsum står.
#Det gør du ud fra variablen Lorem som nu er gjort til str type.
print(Lorem[6:11])
