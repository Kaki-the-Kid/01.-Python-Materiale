#Navn Thomas Suder
#Dato 15/04/2020
#Opgave 4

#float kan tage numeriske værdier med decimaler. 
Netto = float(input ("Venligst, indtast pris uden moms "))
moms = (1.25)

#str gør at så netto og moms kan sættes sammen med en tekst.
print("Pris + moms " + str(Netto*moms) + " kr.")
print("moms udgør 25% af Pris")
print("Tak for besøget!")

