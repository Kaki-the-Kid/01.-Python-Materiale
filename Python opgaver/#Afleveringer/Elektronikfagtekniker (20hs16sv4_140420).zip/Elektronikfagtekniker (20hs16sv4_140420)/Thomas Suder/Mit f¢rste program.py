#Navn Thomas Suder
#Dato 15/04/2020
#Opgave 1

#fx. du laver en variabel som et input som du definerer age.
#til det input laver du så en tekst som fortæller lidt om hvad du forventer til inputtet
#som er hvad er din alder?.
#python bruger + tegnet til at kombinere både tekst og variabler.
age = input ("Hvad er din alder? ")
name = input ("Hvad er dit navn? ")


print("Goddag, "+ name +" du er "+ age + " år gammel")
print("MVH Python")
