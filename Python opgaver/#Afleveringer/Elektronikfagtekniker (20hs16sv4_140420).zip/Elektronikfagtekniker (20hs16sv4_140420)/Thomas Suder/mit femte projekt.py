#Navn Thomas Suder
#Dato 15/04/2020
#Opgave 5


print("Welcome to the US age restriction gatekeeper on movies")
agerestrict = int(input ("Please type your age... "))


if agerestrict >=18:
    print("You may pass to R rated Movies, you're on  your own now")
    

elif agerestrict >=13:
    print("You are allowed to watch PG-13 Movies")
    
else:
    print("You are only allowed to watch PG Movies")

    

