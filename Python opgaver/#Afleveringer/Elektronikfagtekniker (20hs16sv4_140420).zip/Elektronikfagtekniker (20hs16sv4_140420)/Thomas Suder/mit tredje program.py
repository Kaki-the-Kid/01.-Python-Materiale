#Navn Thomas Suder
#Dato 15/04/2020
#Opgave 3

#Denne kode tager ethvert L i str datatype variablen og skifter det ud med et K
Larsten = "Larsten er underviser på AARHUS TECH"

print (Larsten.replace ("L", "K"))